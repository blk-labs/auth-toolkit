"use client";

import { useMemo, useRef, useEffect } from "react";
import { useAuth } from "../hooks/useAuth";
import { createHttpClient } from "@auth-toolkit/core";


export interface UseApiReturn {
  get: HttpClient["get"];
  post: HttpClient["post"];
  put: HttpClient["put"];
  del: HttpClient["del"];
  isReady: boolean;
}

export function useApi(): UseApiReturn {
  const { logout, getTokenStore } = useAuth();

  // 1. Keep a mutable ref to logout to prevent closure staleness
  const logoutRef = useRef(logout);
  useEffect(() => {
    logoutRef.current = logout;
  }, [logout]);

  // 2. Synchronously initialize the HTTP client
  const client = useMemo(() => {
    const tokenStore = getTokenStore();
    return createHttpClient({
      getAccessToken: () => tokenStore.getAccessToken(),
      onLogout: () => {
        logoutRef.current();
      },
    });
  }, [getTokenStore]);

  // 3. Return client methods directly (synchronously ready from frame 1)
  return {
    get: client.get,
    post: client.post,
    put: client.put,
    del: client.del,
    isReady: true,
  };
}

export type { HttpClient };